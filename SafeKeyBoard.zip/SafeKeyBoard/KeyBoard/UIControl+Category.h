//
//  ZSCSafeKeyBoard
//
//  Created by jrjc on 17/2/16.
//  Copyright © 2017年 jrjc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIControl (Category)

@property (nonatomic, strong) NSString *  OrderTags;
@end
