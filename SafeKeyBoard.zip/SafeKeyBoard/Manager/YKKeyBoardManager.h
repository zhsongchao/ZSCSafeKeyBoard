//
//  YKKeyBoardManager.h
//  ZSCSafeKeyBoard
//
//  Created by light on 2018/7/3.
//  Copyright © 2018年 jrjc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Singleton.h"
#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, keyBoardType) {
    NumberKeyBoardShowView,//数字键盘弹出界面
    CharacterKeyBoardShowView,//字符键盘弹出界面
    EnglishKeyBoardShowView,// 英文键盘弹出界面
};

@interface YKKeyBoardManager : NSObject

+ (instancetype)Manager;

- (void)Base64KeyBoardWithTextField:(UITextField *)textField type:(keyBoardType)type;

- (NSString *)deCodeStr;
@end
