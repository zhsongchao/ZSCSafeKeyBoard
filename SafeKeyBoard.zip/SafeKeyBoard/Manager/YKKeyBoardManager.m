//
//  YKKeyBoardManager.m
//  ZSCSafeKeyBoard
//
//  Created by light on 2018/7/3.
//  Copyright © 2018年 jrjc. All rights reserved.
//

#import "YKKeyBoardManager.h"
#import "HZCommanFunc.h"
#import "Base64KeyBoardView.h"

@interface YKKeyBoardManager()<KeyBoardShowViewDelegate,UITextFieldDelegate>

@property (nonatomic,strong) Base64KeyBoardView *keyBoardView;

@property (nonatomic,weak) UITextField *textField;

@property (nonatomic,copy) NSString *codeStr;

@end


@implementation YKKeyBoardManager

+ (instancetype)Manager {

    YKKeyBoardManager *manager = [[self alloc] init];
    
    return manager;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self initKeyBoardView];
    }
    return self;
}

- (void)initKeyBoardView {
    _keyBoardView = [Base64KeyBoardView KeyBoardMenu];
    _keyBoardView.delegate = self;
    _keyBoardView.BlockChnagkeyBoard = ^(UIView *v){
        NSLog(@"改变键盘格式");
    };
}


- (void)Base64KeyBoardWithTextField:(UITextField *)textField type:(keyBoardType)type {

    switch (type) {
        case NumberKeyBoardShowView:
        {
            textField.inputView = [self.keyBoardView NumberKeyBoardShowView];
        }
            break;
        case CharacterKeyBoardShowView:
        {
            textField.inputView = [self.keyBoardView CharacterKeyBoardShowView];
        }
            break;
        case EnglishKeyBoardShowView:
        {
            textField.inputView = [self.keyBoardView EnglishKeyBoardShowView];
        }
            break;
        default:
            break;
    }
    textField.delegate = self;
    self.textField = textField;

}


- (void)getKeyBoardViewValueFromButton:(NSString *)ButtonTxt DidSelectButTag:(NSInteger)BtnTag {
//    NSLog(@"----键盘传过来的数据：%@",ButtonTxt);
    self.textField.text = [Base64KeyBoardView returnByArryCount:ButtonTxt];
    self.codeStr = ButtonTxt;
}

- (void)keyBoardAnmitionDown {
    if ([self.textField isFirstResponder]) {
        [self.textField resignFirstResponder];
    }
}

#pragma mark - 清除按钮点击事件
- (BOOL)textFieldShouldClear:(UITextField *)textField{
    [self.keyBoardView base64TextFieldShouldClear];
    return YES;
}


- (NSString *)deCodeStr {
    return [Base64KeyBoardView tranceBaseToString:self.codeStr]; 
}

@end
